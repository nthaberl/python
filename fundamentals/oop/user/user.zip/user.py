#make_withdrawal(self, amount) - 
    #have this method decrease the user's balance by the amount specified
#display_user_balance(self) - have this method print the user's name and account balance 
    #to the terminal eg. "User: Guido van Rossum, Balance: $150
#BONUS: transfer_money(self, other_user, amount) - have this method decrease the user's balance 
    #by the amount and add that amount to other other_user's balance
class User:
    def __init__(self, name, account_balance):
        self.name = name
        self.account_balance = account_balance
    def make_deposit(self, amount):
        self.account_balance += amount
    def make_withdrawal(self, amount):
        self.account_balance -= amount
    def display_user_balance(self):
        print(f"Name: {self.name}, Account Balance: {self.account_balance}")
    def transfer_money(self, other_user, amount):
        self.account_balance -= amount
        other_user.account_balance += amount
        other_user.display_user_balance()
        print(f"From: {self.name} To: {other_user.name} Amount Transferred: {amount}. {self.name} Balance: {self.account_balance}.")

michael = User("Michael", 500)
guido = User("Guido", 75)
monty = User("Monty", 6500)

michael.make_deposit(50)
michael.make_deposit(100)
michael.make_deposit(125)
michael.make_withdrawal(66)
michael.display_user_balance()
guido.make_deposit(5000)
guido.make_deposit(3500)
guido.make_withdrawal(1500)
guido.make_withdrawal(1337)
guido.display_user_balance()
monty.make_deposit(20)
monty.make_withdrawal(500)
monty.make_withdrawal(1040)
monty.make_withdrawal(5000)
monty.display_user_balance()
michael.transfer_money(monty, 40)
monty.display_user_balance()